

    let envia=() => {
    let form = document.getElementById("frm");
     formulario.action = "proc.php";
     formulario.method = "get" ;
     formulario.submit();
}
